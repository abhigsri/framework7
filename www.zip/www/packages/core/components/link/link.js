export default {
  name: 'link',
};
