export default {
  name: 'appbar',
};
